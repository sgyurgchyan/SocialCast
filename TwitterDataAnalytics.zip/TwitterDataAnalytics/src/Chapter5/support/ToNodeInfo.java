/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Chapter5.support;

/**
 *
 * @author shamanth
 */
public class ToNodeInfo
{
    public int tonodeid;
    public String text;
    public String tousername;
    public String date;
    public int class_code;
    public int catID;
    public String catColor;
    //this is the default direction invert option. If the library adds nodes to the adjacency then that should be set to true in the client side
//    public boolean direction = false;
}
