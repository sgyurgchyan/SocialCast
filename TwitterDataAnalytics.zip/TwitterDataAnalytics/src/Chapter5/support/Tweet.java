/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Chapter5.support;

/**
 *
 * @author shamanth
 */
public class Tweet {
    public String text;
    public long id;
    public double lat;
    public double lng;
    public String pubdate;
    public String user;
    public int catID;
    public String catColor;
}
