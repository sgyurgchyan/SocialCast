/* TweetTracker. Copyright (c) Arizona Board of Regents on behalf of Arizona State University
 * @author shamanth
 */
package utils;

public class OAuthUtils
{
    //Please replace the Consumer key and secret to the one representing your application.
    public static final String CONSUMER_SECRET = "PPCTObQGbGm1gkNvdJiTPKhoTksG787RTBwardkbM";
    public static final String CONSUMER_KEY = "L8CRRCUoRl3xcZ9bdrfUw";
    public static final String REQUEST_TOKEN_URL = "https://twitter.com/oauth/request_token";
    public static final String AUTHORIZE_URL = "https://twitter.com/oauth/authorize";
    public static final String ACCESS_TOKEN_URL = "https://twitter.com/oauth/access_token";

    
    //Use a JFIG file for all the configurations
    public void ReadApplicationIdentity()
    {
        
    }
}
